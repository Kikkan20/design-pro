
import React, { useEffect, useMemo, useState } from "react";

const PROTOTYPE_IMAGES = [
  "/assets/thumbnail.png",
  "/assets/b7415b6a4b2f615f47f193b7f8fce9fdb9c9e12f.png",
  "/assets/879c87ecd71884a7888b61f022b34fdb4388157e.png"
];

// Simple localStorage hook
function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }, [key, value]);
  return [value, setValue];
}

const TABS = [
  { id: "prototype", label: "Prototype", icon: SparklesIcon },
  { id: "tasks", label: "Oppgaver", icon: CheckIcon },
  { id: "notes", label: "Notater", icon: NoteIcon },
  { id: "settings", label: "Innstillinger", icon: CogIcon },
];

export default function App() {
  const [active, setActive] = useLocalStorage("app.tab", "prototype");
  const [theme, setTheme] = useLocalStorage("app.theme", "light");
  const isDark = theme === "dark";

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
      <Header theme={theme} setTheme={setTheme} />
      <main className="mx-auto max-w-5xl p-4 md:p-8">
        <TabBar active={active} setActive={setActive} />
        <div className="mt-6">
          {active === "prototype" && <PrototypeGallery images={PROTOTYPE_IMAGES} />}
          {active === "tasks" && <Tasks />}
          {active === "notes" && <Notes />}
          {active === "settings" && <Settings theme={theme} setTheme={setTheme} />}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Header({ theme, setTheme }) {
  return (
    <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="mx-auto max-w-5xl flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Logo />
          <h1 className="text-xl md:text-2xl font-semibold tracking-tight">Custom Design App</h1>
        </div>
        <div className="flex items-center gap-2">
          <kbd className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs hidden md:inline">React + Tailwind</kbd>
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 dark:border-slate-700 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            aria-label="Bytt tema"
          >
            {theme === "dark" ? <SunIcon /> : <MoonIcon />}
            <span className="text-sm">{theme === "dark" ? "Lyst tema" : "Mørkt tema"}</span>
          </button>
        </div>
      </div>
    </header>
  );
}

function TabBar({ active, setActive }) {
  return (
    <nav className="grid grid-cols-4 gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => setActive(id)}
          className={[
            "flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition",
            active === id
              ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
              : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700",
          ].join(" ")}
          aria-current={active === id ? "page" : undefined}
        >
          <Icon />
          <span className="hidden sm:inline">{label}</span>
        </button>
      ))}
    </nav>
  );
}

// ---------- PROTOTYPE VIEWER ----------
function PrototypeGallery({ images }) {
  const [selected, setSelected] = useState(0);
  useEffect(() => {
    if (selected >= images.length) setSelected(0);
  }, [images, selected]);

  if (!images || images.length === 0) {
    return (
      <EmptyState
        title="Ingen bilder funnet"
        subtitle="Legg prototypens eksporterte bilder i /public/assets og oppdater stiene i koden."
      />
    );
  }

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Prototype</h2>
        <div className="text-sm text-slate-500">{selected + 1} / {images.length}</div>
      </div>

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
        <div className="relative w-full overflow-hidden rounded-xl">
          <img
            src={images[selected]}
            alt={`Prototype ${selected + 1}`}
            className="w-full h-auto object-contain select-none"
          />
        </div>
        <div className="mt-3 flex items-center justify-between">
          <button
            onClick={() => setSelected((s) => (s - 1 + images.length) % images.length)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700"
          >
            Forrige
          </button>
          <div className="flex gap-2 overflow-auto">
            {images.map((src, i) => (
              <button
                key={src + i}
                onClick={() => setSelected(i)}
                className={`rounded-xl border ${i === selected ? "border-slate-900 dark:border-white" : "border-slate-300 dark:border-slate-700"}`}
                title={`Gå til ${i + 1}`}
              >
                <img src={src} alt={"mini " + (i + 1)} className="h-14 w-auto object-cover rounded-lg" />
              </button>
            ))}
          </div>
          <button
            onClick={() => setSelected((s) => (s + 1) % images.length)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700"
          >
            Neste
          </button>
        </div>
      </div>

      <Card className="mt-4" title="Neste steg" subtitle="Gjør prototypen interaktiv.">
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>Bytt ut bilde-galleriet med ekte React-sider per skjerm.</li>
          <li>Definer ruter (f.eks. React Router) for navigasjon.</li>
          <li>Trekk ut farger/typografi til et lite designsystem.</li>
          <li>Legg til klikkbare hotspots for å matche prototypens flyt.</li>
        </ul>
      </Card>
    </section>
  );
}

function EmptyState({ title, subtitle }) {
  return (
    <div className="grid place-items-center border border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-10 text-center">
      <div className="text-base font-semibold">{title}</div>
      <div className="text-sm text-slate-500">{subtitle}</div>
    </div>
  );
}

// ---------- TASKS ----------
function Tasks() {
  const [items, setItems] = useLocalStorage("app.tasks", []);
  const [text, setText] = useState("");
  const [filter, setFilter] = useState("all");

  const left = items.filter((t) => !t.done).length;
  const filtered = useMemo(() => {
    if (filter === "all") return items;
    if (filter === "open") return items.filter((t) => !t.done);
    if (filter === "done") return items.filter((t) => t.done);
    return items;
  }, [items, filter]);

  function addTask() {
    const t = text.trim();
    if (!t) return;
    setItems([{ id: Date.now(), text: t, done: false }, ...items]);
    setText("");
  }

  function toggle(id) {
    setItems(items.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function remove(id) {
    setItems(items.filter((t) => t.id !== id));
  }

  function clearDone() {
    setItems(items.filter((t) => !t.done));
  }

  return (
    <section>
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
        <h2 className="text-lg font-semibold">Oppgaver</h2>
        <div className="text-sm text-slate-500 dark:text-slate-400">{left} igjen</div>
      </div>

      <div className="mt-3 flex gap-2">
        <input
          className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"
          placeholder="Legg til en oppgave…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTask()}
        />
        <button onClick={addTask} className="rounded-xl px-3 py-2 bg-slate-900 text-white dark:bg-white dark:text-slate-900">
          Legg til
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 text-sm">
        {[
          { id: "all", label: "Alle" },
          { id: "open", label: "Åpne" },
          { id: "done", label: "Ferdige" },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 rounded-xl border ${
              filter === f.id
                ? "bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 dark:border-white"
                : "bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700"
            }`}
          >
            {f.label}
          </button>
        ))}
        <button onClick={clearDone} className="ml-auto text-slate-500 hover:text-slate-800 dark:hover:text-slate-200">
          Fjern ferdige
        </button>
      </div>

      <ul className="mt-4 space-y-2">
        {filtered.map((t) => (
          <li key={t.id} className="flex items-center gap-3 rounded-xl border border-slate-200 dark:border-slate-800 p-3">
            <input type="checkbox" checked={t.done} onChange={() => toggle(t.id)} className="size-4" />
            <span className={`flex-1 ${t.done ? "line-through text-slate-400" : ""}`}>{t.text}</span>
            <button onClick={() => remove(t.id)} className="text-slate-400 hover:text-red-500" aria-label="Slett">
              <TrashIcon />
            </button>
          </li>
        ))}
        {filtered.length === 0 && (
          <li className="text-sm text-slate-500">Ingen oppgaver å vise enda.</li>
        )}
      </ul>
    </section>
  );
}

// ---------- NOTES ----------
function Notes() {
  const [notes, setNotes] = useLocalStorage("app.notes", []);
  const [text, setText] = useState("");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return notes.filter((n) => n.text.toLowerCase().includes(q));
  }, [notes, query]);

  function addNote() {
    const t = text.trim();
    if (!t) return;
    setNotes([{ id: Date.now(), text: t, ts: new Date().toISOString() }, ...notes]);
    setText("");
  }

  function removeNote(id) {
    setNotes(notes.filter((n) => n.id !== id));
  }

  return (
    <section>
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
        <h2 className="text-lg font-semibold">Notater</h2>
        <input
          className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm"
          placeholder="Søk i notater…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="mt-3 flex gap-2">
        <textarea
          className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400 h-24"
          placeholder="Skriv et notat… (Markdown støttes, f.eks. **fet**, _kursiv_)"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button onClick={addNote} className="rounded-xl px-3 py-2 bg-slate-900 text-white dark:bg-white dark:text-slate-900 h-fit">
          Lagre
        </button>
      </div>

      <ul className="mt-4 grid md:grid-cols-2 gap-3">
        {filtered.map((n) => (
          <li key={n.id} className="rounded-2xl border border-slate-200 dark:border-slate-800 p-4 bg-white dark:bg-slate-900">
            <div className="flex items-center justify-between mb-2">
              <time className="text-xs text-slate-500" dateTime={n.ts}>{new Date(n.ts).toLocaleString()}</time>
              <button onClick={() => removeNote(n.id)} className="text-slate-400 hover:text-red-500" aria-label="Slett notat">
                <TrashIcon />
              </button>
            </div>
            <Markdown text={n.text} />
          </li>
        ))}
        {filtered.length === 0 && (
          <li className="text-sm text-slate-500">Ingen notater enda.</li>
        )}
      </ul>
    </section>
  );
}

function Settings({ theme, setTheme }) {
  return (
    <section className="space-y-4">
      <h2 className="text-lg font-semibold">Innstillinger</h2>
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-4 bg-white dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-medium">Tema</div>
            <div className="text-sm text-slate-500">Velg lyst eller mørkt.</div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setTheme("light")} className={`${theme === "light" ? "bg-slate-900 text-white border-slate-900" : "border-slate-300 dark:border-slate-700"} px-3 py-1.5 rounded-xl border`}>Lyst</button>
            <button onClick={() => setTheme("dark")} className={`${theme === "dark" ? "bg-slate-900 text-white border-slate-900" : "border-slate-300 dark:border-slate-700"} px-3 py-1.5 rounded-xl border`}>Mørkt</button>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-4 bg-white dark:bg-slate-900">
        <div className="font-medium mb-2">Eksporter data</div>
        <p className="text-sm text-slate-500 mb-3">Last ned oppgaver og notater som JSON.</p>
        <button onClick={exportData} className="px-3 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900">Last ned JSON</button>
      </div>
    </section>
  );
}

function exportData() {
  try {
    const data = {
      tasks: JSON.parse(localStorage.getItem("app.tasks") || "[]"),
      notes: JSON.parse(localStorage.getItem("app.notes") || "[]"),
      meta: { exportedAt: new Date().toISOString(), app: "Custom Design App" },
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `custom-design-app-data-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e) {
    alert("Kunne ikke eksportere data.");
  }
}

// UI primitives
function Card({ title, subtitle, children, className = "" }) {
  return (
    <div className={`rounded-2xl border border-slate-200 dark:border-slate-800 p-5 bg-white dark:bg-slate-900 shadow-sm ${className}`}>
      <div className="mb-3">
        <div className="text-base font-semibold tracking-tight">{title}</div>
        {subtitle && <div className="text-sm text-slate-500">{subtitle}</div>}
      </div>
      {children}
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-10 border-t border-slate-200 dark:border-slate-800">
      <div className="mx-auto max-w-5xl p-6 text-xs text-slate-500 flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
        <div>© {new Date().getFullYear()} Custom Design App</div>
        <div className="flex gap-3">
          <a className="hover:underline" href="#">Personvern</a>
          <a className="hover:underline" href="#">Vilkår</a>
        </div>
      </div>
    </footer>
  );
}

function Markdown({ text }) {
  const html = useMemo(() => {
    let t = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    t = t.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
    t = t.replace(/_(.*?)_/g, "<em>$1</em>");
    t = t.replace(/`(.*?)`/g, "<code class='px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800'>$1</code>");
    t = t.replace(/\n/g, "<br/>");
    return t;
  }, [text]);
  return <div className="prose dark:prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: html }} />;
}

// Icons
function Logo() {
  return (
    <div className="size-8 rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-500 grid place-items-center shadow">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 14a8 8 0 1 0 8-8" />
        <path d="M3 3v5h5" />
      </svg>
    </div>
  );
}
function SparklesIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5z" transform="translate(6 2) scale(0.6)" />
      <path d="M12 2l1.5 3 3 1.5-3 1.5L12 11l-1.5-3L7.5 7.5 10.5 6 12 2z" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function NoteIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6" />
      <path d="M16 13H8" />
      <path d="M16 17H8" />
      <path d="M10 9H8" />
    </svg>
  );
}
function CogIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .67.26 1.3.73 1.77.47.47 1.1.73 1.77.73Z" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
    </svg>
  );
}
function SunIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
    </svg>
  );
}
function MoonIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}
